'''
Probe EF 2022
Programm 2-EMAIL.PY
'''


verteiler = '''
caesonia.reich@gmail.com;

tulugaq.guidi@gmx.ch;

adisa23.palmisano@hispeed.ch;
chinwendu.maclean96@bluewin.ch;

foteini.faron@outlook.com;
'''

mitglieder = []

verteiler = verteiler.strip()

mitglieder = verteiler


# Ziel:
# mitglieder = [                 .
#     ['Caesonia', 'Reich'],     .
#     ['Tulugaq', 'Guidi'],      .
#     ['Adisa', 'Palmisano'],    .
#     ['Chinwendu', 'MacLean'],  .
#     ['Foteini', 'Faron']       .
# ]                              .


print(mitglieder)
