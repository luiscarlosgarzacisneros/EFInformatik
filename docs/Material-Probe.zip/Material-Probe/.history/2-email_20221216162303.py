'''
Probe EF 2022
Programm 2-EMAIL.PY
'''


verteiler = '''
caesonia.reich@gmail.com;

tulugaq.guidi@gmx.ch;

adisa23.palmisano@hispeed.ch;
chinwendu.maclean96@bluewin.ch;

foteini.faron@outlook.com;
'''

verteiler_als_liste = "".join(c for c in verteiler if c.isalpha())


print(verteiler_als_liste)

r = 0
for i in verteiler_als_liste:
    print(verteiler_als_liste[r])
    r = r + 1


# Ziel:
# mitglieder = [                 .
#     ['Caesonia', 'Reich'],     .
#     ['Tulugaq', 'Guidi'],      .
#     ['Adisa', 'Palmisano'],    .
#     ['Chinwendu', 'MacLean'],  .
#     ['Foteini', 'Faron']       .
# ]                              .
