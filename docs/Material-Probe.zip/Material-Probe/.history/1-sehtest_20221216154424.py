'''
Probe EF 2022
Programm 1-SEHTEST.PY
'''


def c(value, richtung):
    for i in range(2):
        for i in range(3 + value):
            print('*', end=' ')
        print('*')
    for i in range(value):
        if richtung == 'L':
            print('* *', end=' ')
            for i in range(value + 2):
                print(' ', end=' ')
            print(' ')
        if richtung == 'R':
            for i in range(value + 2):
                print(' ', end=' ')
            print('* *',)
    for i in range(2):
        for i in range(3 + value):
            print('*', end=' ')
        print('*')


grösse = str(input('grösse'))
richtung = input('richtung')

c(grösse, richtung)
